# Quote of the day

A Pen created on CodePen.io. Original URL: [https://codepen.io/vindhya-9/pen/BaMWVYv](https://codepen.io/vindhya-9/pen/BaMWVYv).

